#ifndef SISTEMA_HPP
#define SISTEMA_HPP

#include "Dicionario.hpp"
#include "Grafo.hpp"
#include "Lista.hpp"
#include "Tema.hpp"
#include "Usuario.hpp"

class Sistema {
	Lista<Usuario> usuarios;
	Lista<Tema> temas;
	Grafo grafo_temas;
	Grafo grafo_social;
	Dicionario dicionario;

	int num_usuarios;
	int num_temas;

	void ordenar_vizinhos(Lista<No *> &lista) const;
	void quickSort_internos(Lista<No *> &lista, int inicio, int fim) const;
	int particionar_vizinhos(Lista<No *> &lista, int inicio, int fim) const;
	void trocar_nos(Lista<No *> &lista, int i, int j) const;

	Lista<int> bfs_distancias_social(int id_interno_social) const;
	float calcular_jaccard(int id_temas_u, int id_temas_v) const;

  public:
	Sistema(TipoGrafo tipoInicial);
	~Sistema();

	void alterar_armazenamento(TipoGrafo tipo);
	const int adicionar_usuario(const std::string &nome, int idade, const Lista<int> &tema_ids);
	const int adicionar_tema(const std::string &nome, TipoTema tipo);
	void seguir_usuario(int id1, int id2);
	void remover_seguimento_usuario(int id1, int id2);
	void consultar_temas(int id_usuario) const;
	void consultar_seguidores(int id_usuario) const;
	void consultar_seguidos(int id_usuario) const;
	void consultar_amigos(int id_usuario) const;
	void consultar_relacao(int id1, int id2) const;
	void consultar_interesse(int id_usuario, int id_tema) const;
	void consultar_popularidade(int id_tema) const;
	void consultar_recomendacao(int id_usuario, int topk, float peso_prox, float peso_afin) const;
};

#endif